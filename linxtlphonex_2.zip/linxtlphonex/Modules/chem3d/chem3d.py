
import wx
import wx.html2 as webview
import os
#----------------------------------------------------------------------

class webchem(wx.Panel):
    def __init__(self, parent):
        wx.Panel.__init__(self, parent)
        self.fnamefull = False
        #self.current = "/home/denis/Dropbox/linxtlphonex/chem3d/index2.html"
        self.fname = os.path.abspath("chem3d/main.html")
        self.dirname = os.curdir


        # self.current = "http://molview.org/"
        # self.current = "https://www.rcsb.org/3d-view/1TRZ/"
        self.frame = self.GetTopLevelParent()
        self.titleBase = self.frame.GetTitle()

        sizer = wx.BoxSizer(wx.VERTICAL)
        btnSizer = wx.BoxSizer(wx.HORIZONTAL)
        self.wv = webview.WebView.New(self)
        # self.Bind(webview.EVT_WEBVIEW_NAVIGATING, self.OnWebViewNavigating, self.wv)
        #self.Bind(webview.EVT_WEBVIEW_NAVIGATED, self.OnWebViewNavigated, self.wv)
        #self.Bind(webview.EVT_WEBVIEW_LOADED, self.OnWebViewLoaded, self.wv)
        #self.Bind(webview.EVT_WEBVIEW_TITLE_CHANGED, self.OnWebViewTitleChanged, self.wv)
        self.Bind(webview.EVT_WEBVIEW_ERROR, self.OnWebViewError, self.wv)

        btn = wx.Button(self, -1, "Open", style=wx.BU_EXACTFIT)
        self.Bind(wx.EVT_BUTTON, self.OpenFile, btn)
        btnSizer.Add(btn, 0, wx.EXPAND|wx.ALL, 2)

        # btn = wx.Button(self, -1, "Open", style=wx.BU_EXACTFIT)
        # self.Bind(wx.EVT_BUTTON, self.OnOpenButton, btn)
        # btnSizer.Add(btn, 0, wx.EXPAND|wx.ALL, 2)

        # btn = wx.Button(self, -1, "<--", style=wx.BU_EXACTFIT)
        # self.Bind(wx.EVT_BUTTON, self.OnPrevPageButton, btn)
        # btnSizer.Add(btn, 0, wx.EXPAND|wx.ALL, 2)
        # self.Bind(wx.EVT_UPDATE_UI, self.OnCheckCanGoBack, btn)

        # btn = wx.Button(self, -1, "-->", style=wx.BU_EXACTFIT)
        # self.Bind(wx.EVT_BUTTON, self.OnNextPageButton, btn)
        # btnSizer.Add(btn, 0, wx.EXPAND|wx.ALL, 2)
        # self.Bind(wx.EVT_UPDATE_UI, self.OnCheckCanGoForward, btn)
        #
        # btn = wx.Button(self, -1, "Stop", style=wx.BU_EXACTFIT)
        # self.Bind(wx.EVT_BUTTON, self.OnStopButton, btn)
        # btnSizer.Add(btn, 0, wx.EXPAND|wx.ALL, 2)

        btn = wx.Button(self, -1, "Refresh", style=wx.BU_EXACTFIT)
        self.Bind(wx.EVT_BUTTON, self.OnRefreshPageButton, btn)
        btnSizer.Add(btn, 0, wx.EXPAND|wx.ALL, 2)

        # txt = wx.StaticText(self, -1, "Location:")
        # btnSizer.Add(txt, 0, wx.CENTER|wx.ALL, 2)

        # self.location = wx.ComboBox(
        #     self, -1, "", style=wx.CB_DROPDOWN|wx.TE_PROCESS_ENTER)
        # self.location.AppendItems(['http://wxPython.org',
        #                            'http://wxwidgets.org',
        #                            'http://google.com'])
        #
        # for url in ['http://wxPython.org',
        #            'http://wxwidgets.org',
        #            'http://google.com']:
        #    item = webview.WebViewHistoryItem(url, url)
        #    self.wv.LoadHistoryItem(item)

        # self.Bind(wx.EVT_COMBOBOX, self.OnLocationSelect, self.location)
        # self.location.Bind(wx.EVT_TEXT_ENTER, self.OnLocationEnter)
        # btnSizer.Add(self.location, 1, wx.EXPAND|wx.ALL, 2)


        sizer.Add(btnSizer, 0, wx.EXPAND)
        sizer.Add(self.wv, 1, wx.EXPAND)
        self.SetSizer(sizer)
        self.writetmp()
        self.current = u'file://' + str(self.fname)
        self.wv.LoadURL(self.current)
        #self.wv.LoadURL(self.current)

    def getfile(self):
       datadict = {}
       # self.filename = "/home/denis/Dropbox/X-ray/GregWelch1/gregw.res"
       file_to_read= open(self.fnamefull, 'r')
       data = [l.rstrip("\n") for l in file_to_read]
       print(os.path.splitext(self.fnamefull)[1])
       datadict["ext"] = os.path.splitext(self.fnamefull)[1][1:]
       datadict["data"] = data
       return datadict


    def writetmp(self):
        if self.fnamefull:
           print(os.path.join(os.path.dirname(self.fname), "main.js"))
           with open(os.path.join(os.path.dirname(self.fname), "main.js"), 'w') as f:
               f.write("var thefile ="+str(self.getfile()))


    # WebView events
    # def OnWebViewNavigating(self, evt):
    #     # this event happens prior to trying to get a resource
    #     if evt.GetURL() == 'http://www.microsoft.com/':
    #         if wx.MessageBox("Are you sure you want to visit Microsoft?",
    #                          style=wx.YES_NO|wx.ICON_QUESTION) == wx.NO:
    #             # This is how you can cancel loading a page.
    #             evt.Veto()


    def OnWebViewNavigated(self, evt):
        self.frame.SetStatusText("Loading %s..." % evt.GetURL())

    def OnWebViewError(self, evt):
        print(evt)
        # self.frame.SetStatusText("Loading %s..." % evt.GetURL())


    def OnWebViewLoaded(self, evt):
        # The full document has loaded
        self.current = evt.GetURL()
        # self.location.SetValue(self.current)
        # self.frame.SetStatusText("Loaded")

        #val =self.wv.RunScript("loadfromfile('/home/denis/Dropbox/linxtlphonex/chem3d/publish.cif', "f");")

        # print(val)
        # self.wv.Reload()
        #print("5345")
        # And you probably want to unbind the event here
        # self.Bind(wx.html2.EVT_WEBVIEW_LOADED, None,
        #           self.wv)
        # self.wv.Reload()


    def OnWebViewTitleChanged(self, evt):
        # Set the frame's title to include the document's title
        self.frame.SetTitle("%s -- %s" % (self.titleBase, evt.GetString()))


    # Control bar events
    # def OnLocationSelect(self, evt):
    #     url = self.location.GetStringSelection()
    #     print('OnLocationSelect: %s\n' % url)
    #     self.wv.LoadURL(url)

    # def OnLocationEnter(self, evt):
    #     url = self.location.GetValue()
    #     self.location.Append(url)
    #     self.wv.LoadURL(url)

    def OpenFile(self, event):

        self.wildcard = "SHELX file (*.res)|*.res;*.RES|Protein Data Bank file (*.pdb)|*.pdb;*.PDB|SHELX file (*.ins)|*.ins;*.INS|Crystallographic information file (*.cif)|*.cif;*.CIF|All Files (*)|*"
        dlg = wx.FileDialog(self, "Choose a file", self.dirname, "", self.wildcard, wx.FD_OPEN)
        if dlg.ShowModal() == wx.ID_OK:
            self.dirname = dlg.GetDirectory()
            self.filename = dlg.GetFilename()
            self.fnamefull = os.path.join(self.dirname, self.filename)
            self.writetmp()
            self.wv.Reload()


    # def OnOpenButton(self, event):
    #     dlg = wx.TextEntryDialog(self, "Open Location",
    #                             "Enter a full URL or local path",
    #                             self.current, wx.OK|wx.CANCEL)
    #     dlg.CentreOnParent()
    #
    #     if dlg.ShowModal() == wx.ID_OK:
    #         self.current = dlg.GetValue()
    #         self.wv.LoadURL(self.current)
    #
    #     dlg.Destroy()

    # def OnPrevPageButton(self, event):
    #     for i in self.wv.GetBackwardHistory():
    #         print("%s %s" % (i.Url, i.Title))
    #     self.wv.GoBack()

    # def OnNextPageButton(self, event):
    #     for i in self.wv.GetForwardHistory():
    #         print("%s %s" % (i.Url, i.Title))
    #     self.wv.GoForward()

    # def OnCheckCanGoBack(self, event):
    #     event.Enable(self.wv.CanGoBack())
    #
    # def OnCheckCanGoForward(self, event):
    #     event.Enable(self.wv.CanGoForward())

    # def OnStopButton(self, evt):
    #     self.wv.Stop()

    def OnRefreshPageButton(self, evt):
        self.wv.Reload()


#----------------------------------------------------------------------


def main():
    app = wx.App()
    frm = wx.Frame(None, title="Chem3D", size=(720, 830))
    frm.CreateStatusBar()
    pnl = webchem(frm)
    frm.Show()
    app.MainLoop()


#----------------------------------------------------------------------

if __name__ == '__main__':
    main()